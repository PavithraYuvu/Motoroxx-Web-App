export const environment = {
  production: true,
  apiUrl : 'https://weelz.fishs.in/api'
};
